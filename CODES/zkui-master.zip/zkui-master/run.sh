docker run \
  -d \
  -p 9090:9090 \
  zkui